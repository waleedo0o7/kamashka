<?php include 'header.php'; ?>

<div class="page-content very-small-content profile support ticket">
    <div class="profile-content">
        <div class="profile-data w-100">
            <div class="container mt-4">
                <h3 class="bold mb-3"> Ticket No.1231321 </h3>

                <div class="ticket-wrapper">

                    <div class="all-messages">


                        <div class="message admin-message"> how can i help you ? </div><!-- message  my-message -->
                        <div class="message my-message"> i'm not able to see my bonus</div><!-- message  my-message -->

                        <div class="message admin-message"> issue shall be resolved within 30 minutes </div><!-- message  my-message -->
                        <div class="message my-message"> Thank You</div><!-- message  my-message -->

                        <div class="message admin-message">the issue is solved now </div><!-- message  my-message -->
                        <div class="message my-message"> Awesome ! </div><!-- message  my-message -->





                        
                        <div class="message admin-message"> how can i help you ? </div><!-- message  my-message -->
                        <div class="message my-message"> i'm not able to see my bonus</div><!-- message  my-message -->

                        <div class="message admin-message"> issue shall be resolved within 30 minutes </div><!-- message  my-message -->
                        <div class="message my-message"> Thank You</div><!-- message  my-message -->

                        <div class="message admin-message">the issue is solved now </div><!-- message  my-message -->
                        <div class="message my-message"> Awesome ! </div><!-- message  my-message -->






                        
                        <div class="message admin-message"> how can i help you ? </div><!-- message  my-message -->
                        <div class="message my-message"> i'm not able to see my bonus</div><!-- message  my-message -->

                        <div class="message admin-message"> issue shall be resolved within 30 minutes </div><!-- message  my-message -->
                        <div class="message my-message"> Thank You</div><!-- message  my-message -->

                        <div class="message admin-message">the issue is solved now </div><!-- message  my-message -->
                        <div class="message my-message"> Awesome ! </div><!-- message  my-message -->





                    </div><!-- all-messages -->

                    <div class="send-message-wrapper relative">
                        <input class="form-control" id="send-message-input" type="text">
                        <i class="fa fa-paper-plane"  id="send-message-input"></i> 
                    </div><!-- send-message-wrapper -->

                </div><!-- ticket-wrapper -->
            </div> <!-- profile-data-content -->
        </div> <!-- profile-data -->
    </div> <!-- profile-content -->
</div><!-- page-content -->

<?php include 'footer.php'; ?>
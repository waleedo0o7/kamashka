<?php include 'header.php'; ?>

<div class="page-content small-content bg-gray pt-5 search-result-empty-page pb-5">
    <div class="container  bg-gray">

        <h3 class="bold mb-4 d-flex"> Search Result </h3>

        <div class="card no-data">
            <img alt="" class="img-fluid" src="img/no-data.svg" alt="">
            <p class="m-0"> No Data Found </p>
        </div><!-- card -->

    </div><!-- container -->
</div><!-- page-content -->

<?php include 'footer.php'; ?>
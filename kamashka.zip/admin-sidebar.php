<div class="sidebar-wrapper">
    <div class="menu">
        <ul class="reset-ul">
            <li> <a class="active" href="admin-dashboard.php"> <i class="fa fa-cog"></i> Dashboard </a></li>
            <li> <a href="admin-taps.php"> <i class="fa fa-cog"></i> Taps </a></li>
            <li> <a href="admin-products.php"> <i class="fa fa-cog"></i> Products </a></li>
            <li> <a href="admin-orders.php"> <i class="fa fa-cog"></i> Orders </a></li>
        </ul>
    </div><!-- menu -->
</div><!-- sidebar -->
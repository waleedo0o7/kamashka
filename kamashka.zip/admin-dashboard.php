<?php include 'admin-header.php'; ?>

<div class="page-content admin dashboard">

    <?php include 'admin-sidebar.php' ?>

    <div class="page-wrapper">

    <h1 class="page-title"> Dashboard </h1>

    </div><!-- page-wrapper -->
</div><!-- page-content -->

<?php include 'admin-footer.php'; ?>
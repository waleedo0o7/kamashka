<?php include 'header.php'; ?>

<div class="page-content small-content profile shares">
    <div class="profile-content">

        <div class="profile-data w-100">
            <div class="profile-data-content mt-2">

                <h3 class="bold mb-4"> My Sharing </h3>

                <div class="shared-ads-wrapper">


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/01.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->

                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/02.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->

                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/03.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->

                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/04.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->

                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/05.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->

                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/06.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->

                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/07.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->

                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/08.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->
                    </div><!-- one-item -->







                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/05.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->
                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/06.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->
                    </div><!-- one-item -->








                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/02.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->
                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/03.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->
                    </div><!-- one-item -->


                    <div class="one-item">
                        <div class="item-content">
                            <img alt="" class="img-fluid" src="img/brand-slider/06.jpg" alt="">
                            <p> FASHION TREND </p>
                            <a href="home.php"> <i class="fa fa-arrow-right"></i> </a>
                            <div class="bottom-shadow"></div><!-- bottom-shadow -->
                        </div><!-- item-content -->

                        <div class="shares-wrapper">
                            <div class="views">
                                <i class="icon icon-eye"></i>
                                <strong> 10 KD </strong>
                            </div><!-- views -->
                            <div class="shares">
                                <i class="icon icon-share"></i>
                                <strong> 30 KD </strong>
                            </div><!-- views -->
                        </div><!-- shares-wrapper -->
                    </div><!-- one-item -->


                </div><!-- shared-ads-wrapper -->






            </div><!-- profile-data-content -->
        </div><!-- profile-data -->
    </div><!-- profile-content -->
</div><!-- page-content -->


<?php include 'footer.php'; ?>

<script>
    onErrorGenderValue();
    calcAge();
</script>
<?php include 'header.php'; ?>

<div class="page-content small-content profile create-advertisement">
    <div class="profile-content">

        <div class="profile-data w-100">
            <div class="profile-data-content mt-4">

                <div class="loading-container">
                    <div class="sbl-circ-path sm"></div>
                </div><!-- loading-container -->

                <br /><br /><br />

                <div class="loading-container">
                    <div class="sbl-circ-path md"></div>
                </div><!-- loading-container -->

                <br /><br /><br />


                <div class="loading-container">
                    <div class="sbl-circ-path lg"></div>
                </div><!-- loading-container -->



            </div><!-- profile-data-content -->
        </div><!-- profile-data -->
    </div><!-- profile-content -->
</div><!-- page-content -->


<?php include 'footer.php'; ?>

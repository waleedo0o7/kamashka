<?php include 'admin-header.php'; ?>

<div class="page-content admin admin-product-under-review-page ">

    <div class="admin-product-under-review-wrapper text-center">
        <img alt="" src="img/success.gif" />
        <h2 class=""> Product Under Review </h2>
        <p class="lead">Your product was placed successfully. we Will <br /> Review Your product Within 7 Days</p>
        <a class="btn btn-custom1" href="#"> Home </a>
    </div><!-- admin-product-under-review-wrapper -->

</div><!-- page-content -->

<?php include 'admin-footer.php'; ?>